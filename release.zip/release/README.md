# temp-cleaner 2.0

Windows 桌面悬浮胶囊版临时文件清理工具。启动后显示 CPU、内存和硬件可提供时的温度；点击“一键清理”后会先扫描，再自动清理程序白名单中的临时文件和浏览器缓存；不会逐项要求勾选。清理范围刻意限制在安全目标内。

## 本版变化

- 半透明、置顶、可拖动的桌面胶囊；右键菜单可一键清理或退出。
- 显示 CPU 使用率、内存使用率，以及"上次清理释放了多少"（读日志最后一条记录）。
- 扫描用户临时目录、Windows 临时目录、Chrome Default 缓存、Edge Default 缓存，显示估算大小和文件数量。
- 一键完成扫描和清理；清理后显示实际释放空间、删除数量、跳过数量和耗时。
- 不默认设置开机自启动，不静默清理，不创建隐藏启动任务。
- 路径必须匹配程序允许的默认目标，目录名还需命中白名单；拒绝网络路径、用户数据黑名单路径、符号链接/目录联接；遇到占用或权限问题会跳过。
- 可选日志写入 `%LOCALAPPDATA%\temp-cleaner.log`。

## 使用

### 本版修正（接手后的一轮审查）

- 删掉了从未被调用的"勾选确认"界面（约 110 行死代码），main.py 的文档字符串改成描述
  真实行为：点"一键清理"= 先扫描估算大小、再直接清理白名单目录，清理后弹窗报告结果。
- 加了**单实例保护**（命名互斥量）：重复双击不会再开出第二个胶囊，避免两个清理器
  同时删同一批文件。
- 扫描/清理线程回 UI 时对 `TclError` 做了兜底：扫描中途点 × 退出，不会在后台线程里
  抛出没人看得见的异常。
- `requirements.txt` 只保留运行时依赖（psutil，可选）；PyInstaller 属于构建工具，
  改由 `build.bat` 单独安装，不再当成程序依赖。
- 移除了源码里附带的 `__pycache__`（源码包不应该带字节码）。

### 从源码运行

安装 Python 3.10 或更新版本，然后：

```powershell
python -m pip install -r requirements.txt
python main.py
```

### 打包成 Windows 程序

在 Windows 上双击 `build.bat`。构建完成后，分发 `release` 文件夹整体压缩包：

```text
release\
  temp-cleaner\   temp-cleaner.exe + _internal\
  uninstall\      uninstall.exe + _internal\
  README.md
```

不要单独移动 `temp-cleaner.exe`，`_internal` 运行时目录必须一起保留。程序不会自动安装或设置开机自启动；如果用户希望开机运行，应由用户自行创建快捷方式并明确选择。

## 为什么没有温度

上一版第三行显示"温度"，在 Windows 上永远是"不支持"——不是硬件问题，而是这条路走不通：

1. `psutil.sensors_temperatures()` **在 Windows 上根本不存在**（只有 Linux/BSD/macOS 有，
   实测 psutil 7.2.2 里连这个属性都没有），所以代码只会落到兜底分支；
2. Windows 用户态唯一可能拿到温度的是 ACPI 热区（`root\WMI` 的
   `MSAcpi_ThermalZoneTemperature`），但它在多数整机上要么不实现、要么**需要管理员权限**
   （实测这台机器返回"拒绝访问"），而且给的是主板/外壳温区，不是 CPU 核心温度；
3. CPU 核心温度要直接读 MSR，必须有**签名的内核驱动**——这就是 HWMonitor / HWiNFO 之类
   工具都要装驱动的原因。

一个"免安装、免驱动、免管理员"的小工具注定读不到核心温度，所以这一格改成展示本工具
自己的成果：上次清理释放了多少。

## 清理范围

一键清理**不包含** Windows 更新下载缓存、WinSxS 组件存储、`Windows.old`、系统还原点、回收站、下载目录和个人文档。尤其不能直接清空 `WinSxS` 或 `SoftwareDistribution` 文件夹。Windows 更新相关清理应另行调用 Windows 自带维护/清理机制，并明确提示用户其影响；本版本不会擅自处理这些项目。


- 当前用户 `%TEMP%`（或 `%TMP%`）
- `%SystemRoot%\Temp`
- `%LOCALAPPDATA%\Google\Chrome\User Data\Default\Cache`
- `%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\Cache`

浏览器仅处理 Default 配置文件的 Cache 目录。Cookies、History、登录数据、书签、偏好设置等路径被列入拒绝名单，不会作为目标清理。正在使用的文件可能无法删除，会被跳过。扫描大小是估算值，实际释放量以清理完成报告为准。

## 卸载

先退出悬浮胶囊，再运行 `release\uninstall\uninstall.exe`，输入 `YES` 确认。它会尝试移除旧版本遗留的启动快捷方式/启动项、日志和主程序目录。卸载程序自身不会隐藏删除自己；确认卸载后可以手动删除 `uninstall` 文件夹。

## 安全与限制

这是试用版本。请先在测试环境验证，再交给其他人使用。程序只扫描和清理列明的目录，不承诺能提升所有电脑的性能；“加速”面板中的 CPU/内存指标只是状态信息，不会通过强制释放内存来制造虚假的加速效果。不要让用户关闭杀毒软件或添加整个目录的排除项；如果安全软件报警，应先检查检测名称和构建产物，并向厂商提交误报分析。
